package com.ddeeng.app

import android.content.Context
import java.io.File
import kotlin.math.*

/** 단속카메라 한 곳 */
data class Cam(
    val lat: Double,
    val lng: Double,
    val limit: Int,       // 제한속도(km/h), 없으면 0
    val kind: String,     // 단속구분(과속/구간단속 등)
    val name: String      // 지점명/주소
)

/**
 * 경찰청 무인단속카메라 표준데이터(CSV)를 읽어 격자 색인으로 보관.
 * 전국 3만여 건도 즉시 조회된다.
 */
object CameraRepo {

    private const val CELL = 0.01              // 약 1.1km 격자
    private var cams: List<Cam> = emptyList()
    private val grid = HashMap<Long, MutableList<Int>>()

    val size: Int get() = cams.size

    private fun cellKey(la: Double, ln: Double): Long {
        val a = Math.round(la / CELL)
        val o = Math.round(ln / CELL)
        return (a shl 22) xor (o and 0x3FFFFFL)
    }

    /** 앱 시작 시 호출. 사용자가 가져온 파일이 있으면 그걸, 없으면 번들 샘플을 로드. */
    fun load(ctx: Context) {
        val userFile = File(ctx.filesDir, "cameras.csv")
        val text: String = if (userFile.exists()) {
            readSmart(userFile.readBytes())
        } else {
            readSmart(ctx.assets.open("cameras_sample.csv").readBytes())
        }
        parse(text)
    }

    /** 사용자가 고른 CSV 원문을 내부 저장소에 복사하고 다시 로드. */
    fun importCsv(ctx: Context, bytes: ByteArray): Int {
        val text = readSmart(bytes)
        parse(text)                            // 먼저 검증(예외 시 저장 안 함)
        File(ctx.filesDir, "cameras.csv").writeBytes(bytes)
        return cams.size
    }

    /** 반경 내 후보 카메라. */
    fun nearby(la: Double, ln: Double, radiusM: Double): List<Cam> {
        if (cams.isEmpty()) return emptyList()
        val r = ceil(radiusM / 1000.0 / 1.1).toInt() + 1
        val ba = Math.round(la / CELL)
        val bo = Math.round(ln / CELL)
        val out = ArrayList<Cam>()
        for (x in -r..r) for (y in -r..r) {
            val key = ((ba + x) shl 22) xor ((bo + y) and 0x3FFFFFL)
            grid[key]?.forEach { out.add(cams[it]) }
        }
        return out
    }

    // ---- 내부 ----

    /** 표준데이터 기본 인코딩(EUC-KR) 우선, 깨지면 UTF-8 재시도. */
    private fun readSmart(bytes: ByteArray): String {
        val euc = String(bytes, charset("EUC-KR"))
        return if (euc.take(400).contains('\uFFFD')) String(bytes, Charsets.UTF_8) else euc
    }

    private fun splitLine(l: String): List<String> {
        val out = ArrayList<String>(); val cur = StringBuilder(); var q = false
        var i = 0
        while (i < l.length) {
            val c = l[i]
            when {
                c == '"' -> if (q && i + 1 < l.length && l[i + 1] == '"') { cur.append('"'); i++ } else q = !q
                c == ',' && !q -> { out.add(cur.toString()); cur.setLength(0) }
                else -> cur.append(c)
            }
            i++
        }
        out.add(cur.toString()); return out
    }

    private fun findCol(hdr: List<String>, keys: List<String>): Int {
        for (i in hdr.indices) {
            val h = hdr[i].replace(Regex("[\\s\"']"), "")
            if (keys.any { h.contains(it) }) return i
        }
        return -1
    }

    private fun parse(text: String) {
        val lines = text.split(Regex("\\r?\\n")).filter { it.isNotBlank() }
        require(lines.isNotEmpty()) { "빈 파일입니다." }
        val hdr = splitLine(lines[0])
        val iLat = findCol(hdr, listOf("위도", "latitude", "lat"))
        val iLng = findCol(hdr, listOf("경도", "longitude", "lng", "lon"))
        require(iLat >= 0 && iLng >= 0) { "위도·경도 열을 찾지 못했습니다. 표준데이터 CSV가 맞는지 확인하세요." }
        val iLim = findCol(hdr, listOf("제한속도", "속도"))
        val iKind = findCol(hdr, listOf("단속구분", "단속종류", "시설종류"))
        val iName = findCol(hdr, listOf("지점명", "설치장소", "소재지도로명주소", "주소"))

        val list = ArrayList<Cam>()
        for (k in 1 until lines.size) {
            val c = splitLine(lines[k])
            val la = c.getOrNull(iLat)?.trim()?.toDoubleOrNull() ?: continue
            val ln = c.getOrNull(iLng)?.trim()?.toDoubleOrNull() ?: continue
            if (la < 32.0 || la > 39.8 || ln < 124.0 || ln > 132.2) continue   // 한반도 밖 제거
            val kind = if (iKind >= 0) c.getOrElse(iKind) { "" }.replace("\"", "") else ""
            if (Regex("주정차|주차").containsMatchIn(kind)) continue           // 주정차 단속 제외
            list.add(
                Cam(
                    lat = la, lng = ln,
                    limit = if (iLim >= 0) c.getOrNull(iLim)?.trim()?.toIntOrNull() ?: 0 else 0,
                    kind = kind,
                    name = if (iName >= 0) c.getOrElse(iName) { "" }.replace("\"", "").take(28) else ""
                )
            )
        }
        require(list.isNotEmpty()) { "유효한 좌표가 한 건도 없습니다." }

        cams = list
        grid.clear()
        cams.forEachIndexed { idx, cam ->
            grid.getOrPut(cellKey(cam.lat, cam.lng)) { ArrayList() }.add(idx)
        }
    }

    // ---- 지오 유틸(서비스에서 사용) ----
    fun distanceM(a1: Double, o1: Double, a2: Double, o2: Double): Double {
        val R = 6371000.0
        val dLa = Math.toRadians(a2 - a1); val dLo = Math.toRadians(o2 - o1)
        val h = sin(dLa / 2).pow(2) +
                cos(Math.toRadians(a1)) * cos(Math.toRadians(a2)) * sin(dLo / 2).pow(2)
        return 2 * R * asin(sqrt(h))
    }

    fun bearing(a1: Double, o1: Double, a2: Double, o2: Double): Double {
        val y = sin(Math.toRadians(o2 - o1)) * cos(Math.toRadians(a2))
        val x = cos(Math.toRadians(a1)) * sin(Math.toRadians(a2)) -
                sin(Math.toRadians(a1)) * cos(Math.toRadians(a2)) * cos(Math.toRadians(o2 - o1))
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    fun angleDiff(a: Double, b: Double): Double {
        val d = abs(a - b) % 360
        return if (d > 180) 360 - d else d
    }
}
