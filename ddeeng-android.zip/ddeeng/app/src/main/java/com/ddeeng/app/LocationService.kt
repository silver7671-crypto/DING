package com.ddeeng.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*

/**
 * 포그라운드 위치 서비스.
 * 폰 GPS로 위치를 받아 500m 앞·진행 방향의 카메라를 만나면 "띵" 한 번.
 * 포그라운드 서비스라 화면이 꺼지거나 폰이 잠겨도 계속 돈다.
 */
class LocationService : Service() {

    companion object {
        const val CH_ALERT = "ddeeng_alert"     // 띵
        const val CH_ONGOING = "ddeeng_ongoing" // 상시 알림(서비스 유지용)
        const val NOTI_ID = 1001
        var running = false; private set
        var lastStatus: String = "대기 중"; private set

        // 설정(1단계 고정값; UI에서 변경 가능)
        @Volatile var radiusM = 500.0
        @Volatile var coneDeg = 90.0            // ±45°. 360이면 반경만 판정
    }

    private lateinit var fused: FusedLocationProviderClient
    private var tone: ToneGenerator? = null
    private var vib: Vibrator? = null
    private val cooldown = HashMap<String, Long>()   // 카메라별 마지막 알림 시각

    private val callback = object : LocationCallback() {
        override fun onLocationResult(res: LocationResult) {
            res.lastLocation?.let { onLoc(it) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        vib = if (Build.VERSION.SDK_INT >= 31)
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        createChannels()
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }

        val noti = ongoingNoti("감시 중 · 카메라 ${CameraRepo.size}곳")
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(NOTI_ID, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(NOTI_ID, noti)

        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(1000L)
            .setMinUpdateDistanceMeters(0f)
            .build()
        try {
            fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
        } catch (_: SecurityException) { /* 권한 없음 */ }

        running = true
        return START_STICKY
    }

    private fun onLoc(loc: Location) {
        val la = loc.latitude; val ln = loc.longitude
        val kmh = if (loc.hasSpeed()) (loc.speed * 3.6).toInt() else -1
        val now = System.currentTimeMillis()

        var best: Cam? = null; var bestD = Double.MAX_VALUE
        for (c in CameraRepo.nearby(la, ln, radiusM)) {
            val d = CameraRepo.distanceM(la, ln, c.lat, c.lng)
            if (d > radiusM) continue
            // 진행 방향 판정: 충분히 빠르고 방위 정보가 있을 때만
            if (coneDeg < 360 && loc.hasBearing() && kmh > 15) {
                val br = CameraRepo.bearing(la, ln, c.lat, c.lng)
                if (CameraRepo.angleDiff(br, loc.bearing.toDouble()) > coneDeg / 2) continue
            }
            if (d < bestD) { bestD = d; best = c }

            val key = "%.5f,%.5f".format(c.lat, c.lng)
            val last = cooldown[key] ?: 0L
            if (now - last > 90_000) {          // 같은 카메라 90초 내 재알림 금지
                cooldown[key] = now
                ding(c.kind.contains("구간"))
            }
        }
        if (cooldown.size > 400) cooldown.entries.removeAll { now - it.value > 300_000 }

        lastStatus = if (best != null) {
            val lim = if (best.limit > 0) "${best.limit}km/h · " else ""
            "${best.kind.ifBlank { "단속" }} $lim${bestD.toInt()}m 앞"
        } else "주행 중" + if (kmh >= 0) " · ${kmh}km/h" else ""
        updateNoti(lastStatus)
    }

    /** 띵: 구간단속은 낮은 음, 고정식은 높은 음. 진동 함께. */
    private fun ding(zone: Boolean) {
        tone?.startTone(
            if (zone) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP,
            220
        )
        if (Build.VERSION.SDK_INT >= 26)
            vib?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vib?.vibrate(40)
    }

    // ---- 알림 채널/노티 ----
    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(CH_ONGOING, "감시 상태", NotificationManager.IMPORTANCE_LOW)
        )
        mgr.createNotificationChannel(
            NotificationChannel(CH_ALERT, "카메라 알림", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)   // 소리는 ToneGenerator로 직접 내므로 알림음은 끔
            }
        )
    }

    private fun ongoingNoti(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LocationService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_ONGOING)
            .setContentTitle("띵 — 단속카메라 감시")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "정지", stop)
            .build()
    }

    private fun updateNoti(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTI_ID, ongoingNoti(text))
    }

    override fun onDestroy() {
        running = false
        lastStatus = "정지됨"
        fused.removeLocationUpdates(callback)
        tone?.release(); tone = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
