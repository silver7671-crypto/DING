package com.ddeeng.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var toggle: Button

    // CSV 가져오기
    private val pickCsv = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val n = CameraRepo.importCsv(this, bytes)
            toast("카메라 ${n}곳을 불러왔습니다.")
            refresh()
        } catch (e: Exception) {
            AlertDialog.Builder(this)
                .setTitle("불러오기 실패")
                .setMessage(e.message ?: "알 수 없는 오류")
                .setPositiveButton("확인", null).show()
        }
    }

    // 권한 요청
    private val askPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startAfterPerms() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        count = findViewById(R.id.count)
        toggle = findViewById(R.id.toggle)

        CameraRepo.load(this)   // 저장된 파일 또는 번들 샘플

        findViewById<Button>(R.id.importBtn).setOnClickListener {
            pickCsv.launch(arrayOf("text/*", "text/csv", "text/comma-separated-values", "application/octet-stream"))
        }

        val radius = findViewById<Spinner>(R.id.radius)
        radius.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("300m 앞", "500m 앞", "800m 앞")
        )
        radius.setSelection(1)  // 500m
        radius.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                LocationService.radiusM = listOf(300.0, 500.0, 800.0)[pos]
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        toggle.setOnClickListener {
            if (LocationService.running) stopService()
            else ensurePermsThenStart()
        }
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        count.text = "카메라 ${CameraRepo.size}곳"
        val on = LocationService.running
        toggle.text = if (on) "정지" else "출발"
        status.text = if (on) LocationService.lastStatus else "대기 중"
    }

    // ---- 권한 ----
    private fun ensurePermsThenStart() {
        val need = ArrayList<String>()
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION))
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
            need.add(Manifest.permission.POST_NOTIFICATIONS)

        if (need.isNotEmpty()) { askPerms.launch(need.toTypedArray()); return }
        maybeAskBackground()
    }

    private fun startAfterPerms() {
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) maybeAskBackground()
        else toast("위치 권한이 필요합니다.")
    }

    /** 화면 꺼짐/잠금에도 알림받으려면 '항상 허용'(백그라운드 위치)이 필요. */
    private fun maybeAskBackground() {
        if (Build.VERSION.SDK_INT >= 29 &&
            !granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        ) {
            AlertDialog.Builder(this)
                .setTitle("‘항상 허용’ 필요")
                .setMessage("화면이 꺼지거나 폰이 잠겨도 알림을 받으려면 위치 권한을 ‘항상 허용’으로 설정해야 합니다.\n\n다음 화면에서 ‘항상 허용’을 선택하세요.")
                .setPositiveButton("설정하기") { _, _ ->
                    askPerms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
                }
                .setNegativeButton("나중에") { _, _ -> startService() }
                .show()
            return
        }
        startService()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ---- 서비스 ----
    private fun startService() {
        if (CameraRepo.size == 0) { toast("먼저 카메라 CSV를 불러오세요."); return }
        val i = Intent(this, LocationService::class.java)
        ContextCompat.startForegroundService(this, i)
        toggle.postDelayed({ refresh() }, 400)
    }

    private fun stopService() {
        startService(Intent(this, LocationService::class.java).setAction("STOP"))
        toggle.postDelayed({ refresh() }, 400)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
